

<!DOCTYPE html>

<html>

<head>

    <title>Success</title>


    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- FONT AWESOME -->


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">



    <!-- GOOGLE FONTS -->


    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">


    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


    <link rel="stylesheet" type="text/css" href="css/stylesheet.css">



                <script type="text/javascript" src="javascript.js"></script>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>




</head>


<body>




	    <div class="container-fluid">
	        <div class="container services3">
	            <div class="flex-parent-success">


	                <div class="flex-child-success">

	                  <img src="images/relax.svg"><br>
	                  <h3>Relax</h3>
	                  <p class="lead"><small>Your message has been sent, We will get back to you shortly.</small>
	                </div>

	            </div>
	        </div>

	    </div>





    <!-- <div id="bar-main">
      <div class="container">



        <div class="bar-hero-content">


        </div>
    </div>

</div> -->



    <footer class="actionpage">


        <div class="container-fluid">


            <div class="row">

                <div class="col-sm-12 text-center">

                   Made with <a href="3">VY Local</a>



                </div>
            </div>
        </div>
    </footer>









</body>

</html>
